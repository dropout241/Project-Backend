## Chat room

- A Slack room has been set up for the duration of the training

- We'll use it to ask questions, get help, share feedback ...

  (let's keep an eye on it during the training!)

- Reminder, the room is @@CHAT@@

- Say hi in the chat room!

