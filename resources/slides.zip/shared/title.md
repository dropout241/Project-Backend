class: title, self-paced

@@TITLE@@

.nav[*Self-paced version*]

---

class: title, in-person

@@TITLE@@<br/></br>

.footnote[
**Slides[:](https://www.youtube.com/watch?v=h16zyxiwDLY) @@SLIDES@@**
]

<!--
WiFi: **Something**<br/>
Password: **Something**

**Be kind to the WiFi!**<br/>
*Use the 5G network.*
*Don't use your hotspot.*<br/>
*Don't stream videos or download big files during the workshop*<br/>
*Thank you!*
-->
