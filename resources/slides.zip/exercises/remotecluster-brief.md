## Exercise — Remote Cluster

- Install kubectl locally

- Retrieve the kubeconfig file of our remote cluster

- Deploy dockercoins on that cluster

- Access an internal service without exposing it
