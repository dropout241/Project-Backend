## Exercise — Healthchecks

- Add readiness and liveness probes to a web service

  (we will use the `rng` service in the dockercoins app)

- See what happens when the load increases

  (spoiler alert: it involves timeouts!)
