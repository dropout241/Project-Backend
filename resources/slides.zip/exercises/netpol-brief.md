## Exercise — Network Policies

- Implement a system with 3 levels of security

  (private pods, public pods, namespace pods)

- Apply it to the DockerCoins demo app
