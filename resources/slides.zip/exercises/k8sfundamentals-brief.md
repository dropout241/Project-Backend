## Exercise — Deploy Dockercoins

- Deploy the dockercoins application to our Kubernetes cluster

- Connect components together

- Expose the web UI and open it in a web browser to check that it works
