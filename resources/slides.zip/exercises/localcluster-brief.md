## Exercise — Local Cluster

- Deploy a local Kubernetes cluster if you don't already have one

- Deploy dockercoins on that cluster

- Connect to the web UI in your browser

- Scale up dockercoins
