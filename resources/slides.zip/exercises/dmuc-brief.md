## Exercise — Build a Cluster

- Deploy a cluster by configuring and running each component manually

- Add CNI networking

- Generate and validate ServiceAccount tokens
