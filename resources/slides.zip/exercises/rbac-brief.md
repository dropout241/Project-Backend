## Exercise — RBAC

- Create two namespaces for users `alice` and `bob`

- Give each user full access to their own namespace

- Give each user read-only access to the other's namespace

- Let `alice` view the nodes of the cluster as well
