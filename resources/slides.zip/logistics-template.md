## Introductions

⚠️ This slide should be customized by the tutorial instructor(s).

<!--

- Hello! We are:

   - 👷🏻‍♀️ AJ ([@s0ulshake], [EphemeraSearch], [Quantgene])

   - 🚁 Alexandre ([@alexbuisine], Enix SAS)

   - 🐳 Jérôme ([@jpetazzo], Ardan Labs)

   - 🐳 Jérôme ([@jpetazzo], Enix SAS)

   - 🐳 Jérôme ([@jpetazzo], Tiny Shell Script LLC)

-->

<!--

- The training will run for 4 hours, with a 10 minutes break every hour

  (the middle break will be a bit longer)

-->

<!--

- The workshop will run from XXX to YYY

- There will be a lunch break at ZZZ

  (And coffee breaks!)

-->

<!--

- Feel free to interrupt for questions at any time

- *Especially when you see full screen container pictures!*

- Live feedback, questions, help: @@CHAT@@

-->

<!--

- You ~~should~~ must ask questions! Lots of questions!

  (especially when you see full screen container pictures)

- Use @@CHAT@@ to ask questions, get help, etc.

-->

<!-- -->

[@alexbuisine]: https://twitter.com/alexbuisine
[EphemeraSearch]: https://ephemerasearch.com/
[@jpetazzo]: https://twitter.com/jpetazzo
[@s0ulshake]: https://twitter.com/s0ulshake
[Quantgene]: https://www.quantgene.com/

---

## Exercises

- At the end of each day, there is a series of exercises

- To make the most out of the training, please try the exercises!

  (it will help to practice and memorize the content of the day)

- We recommend to take at least one hour to work on the exercises

  (if you understood the content of the day, it will be much faster)

- Each day will start with a quick review of the exercises of the previous day
