# Links and resources

- [Microsoft Learn](https://docs.microsoft.com/learn/)

- [Azure Kubernetes Service](https://docs.microsoft.com/azure/aks/)

- [Cloud Developer Advocates](https://developer.microsoft.com/advocates/)

- [Kubernetes Community](https://kubernetes.io/community/) - Slack, Google Groups, meetups

- [Local meetups](https://www.meetup.com/)

- [devopsdays](https://www.devopsdays.org/)

.footnote[These slides (and future updates) are on → http://container.training/]
